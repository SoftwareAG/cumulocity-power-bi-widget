(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["powerbi-runtime-widget"],{

/***/ "@angular/core":
/*!******************************!*\
  !*** external "AngularCore" ***!
  \******************************/
/***/ (function(module, exports) {

module.exports = AngularCore;

/***/ }),

/***/ "@angular/forms":
/*!*******************************!*\
  !*** external "AngularForms" ***!
  \*******************************/
/***/ (function(module, exports) {

module.exports = AngularForms;

/***/ }),

/***/ "@angular/router":
/*!********************************!*\
  !*** external "AngularRouter" ***!
  \********************************/
/***/ (function(module, exports) {

module.exports = AngularRouter;

/***/ }),

/***/ "@c8y/client":
/*!****************************!*\
  !*** external "C8yClient" ***!
  \****************************/
/***/ (function(module, exports) {

module.exports = C8yClient;

/***/ }),

/***/ "@c8y/ngx-components":
/*!***********************************!*\
  !*** external "C8yNgxComponents" ***!
  \***********************************/
/***/ (function(module, exports) {

module.exports = C8yNgxComponents;

/***/ })

},[["powerbi-runtime-widget-CustomWidget","webpackRuntime","powerbi-runtime-widget-stylejs","powerbi-runtime-widget-CustomWidget","powerbi-runtime-widget~vendors~powerbi-runtime-widget"]]]);
//# sourceMappingURL=powerbi-runtime-widget.c961e87fde0002f73c99.js.map